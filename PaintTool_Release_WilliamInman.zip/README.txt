CREATED BY WILLIAM INMAN

- Cntrl + z to undo current tool (lines and shapes are one of the same, both will be deleted)
- "C" to open colour menu when in PopOutMenu
- "A" to open shapes menu when in PopOutMenu
- Shapes Brush Offsets placed shape by a small amount
- Shapes Brush Increases Scale OutWard Front Centre (Mouse Click is shape centre)
- Input Fields Only Work If They Are Moused Over (Clicking does nothing)
- All Input Fields are limited to 999 (including the canvas) (dident have time to make it seperate)
- If a brush or shape is too large for the canvas, it will still paint it but when saving, only the Stuff inside the canvas gets saved
- All current changes are discarded and the canvas is wiped clean when loading an image or resizing the canvas.

Enjoy and thank you for the cool assignment :)